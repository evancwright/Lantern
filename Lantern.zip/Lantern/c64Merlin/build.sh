#!/bin/sh

if  [ ! -e ../bin/c1541.exe ]
then
	echo "You need c1541.exe in the Lantern's bin folder to attach your game to a disk image."
   exit
fi

if  [ -e __DISK_NAME__.d64 ]
then
   rm -f __DISK_NAME__.64
fi

cp blank.d64 __DISK_NAME__.d64
 
echo "attaching program to disk image..."
../bin/c1541 -attach __DISK_NAME__.d64 -write __DISK_NAME__.prg

echo "Reminder:"
echo "LOAD \"*\",8 loads the directory" 
echo "THE * key is the  ] key"
