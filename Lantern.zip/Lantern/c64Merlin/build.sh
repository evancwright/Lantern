#!/bin/sh

if  [ ! -e ../bin/c1541.exe ]
then
	echo "You need c1541.exe in the Lantern's bin folder to attach your game to a disk image."
   exit
fi

if  [ -e __DISK_NAME__.d64 ]
then
   rm -f __DISK_NAME__.64
fi

cp blank.d64 __DISK_NAME__.d64
 
echo "attaching program to disk image..."
#if there is a loader, attach it as name.prg and the game as data.seq


if [ -e loader.bin ]
then
#attach the loader
	../bin/c1541 -attach __DISK_NAME__.d64 -write loader.bin __DISK_NAME__.prg 
#attach the data 	
	../bin/c1541 -attach __DISK_NAME__.d64 -write __DISK_NAME__.prg data.seq
	../bin/c1541 -attach __DISK_NAME__.d64 -write __DISK_NAME__.prg game.prg
else
#no loader, just attach the main file
	../bin/c1541 -attach __DISK_NAME__.d64 -write __DISK_NAME__.bin __DISK_NAME__.prg 
fi

echo "Reminder:"
echo "LOAD \"*\",8 loads the directory" 
echo "THE * key is the  ] key"
