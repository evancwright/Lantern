Launch BEEBEM
Open advgame.ssd
Attach ADVDATA to 
*CAT to see files
*LOAD ADVDATA  20000
PRINT USR(&2000)