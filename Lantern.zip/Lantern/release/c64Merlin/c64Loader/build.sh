#!/bin/sh
cp blank.d64 test.d64
if [[ -s "loading.seq" ]]
then
	cp ../c64Merlin/loader2.s ./loader.s

	../bin/Merlin32.exe -V ../Merlin32_v1.0/Library/ loader.s
#../bin/Merlin32.exe -V ../Merlin32_v1.0/Library/ bmp.s
	 
	echo "attaching program to disk image..."
	../bin/c1541 -attach test.d64 -write loader advent.prg 
	../bin/c1541 -attach test.d64 -write loading.seq loading.seq
#	../bin/c1541 -attach test.d64 -write main advent.seq

else
 	../bin/c1541 -attach test.d64 -write  main advent.prg
fi

echo "Reminder:"
echo "LOAD \"*\",8 loads the directory" 
echo "THE * key is the  ] key"
