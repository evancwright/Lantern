#!/bin/bash
 

../bin/AppleWin.exe -d1 __DISK_NAME__ 

