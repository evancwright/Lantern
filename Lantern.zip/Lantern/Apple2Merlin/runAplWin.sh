#!/bin/bash
dsk=`ls *.dsk`
../apple2/AppleWin.exe -d1 $dsk
