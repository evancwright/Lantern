#!/bin/bash
 

../apple2/AppleWin.exe -d1 __DISK_NAME__ 

