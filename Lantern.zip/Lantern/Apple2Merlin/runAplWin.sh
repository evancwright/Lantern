#!/bin/bash
dsk=`ls *.dsk`

python ../dsk2po.py $dsk

../apple2/AppleWin.exe -d1 $dsk

