#!/bin/bash

python ../dsk2po.py __DISK_NAME__  

../apple2/AppleWin.exe -d1 __DISK_NAME__ 

