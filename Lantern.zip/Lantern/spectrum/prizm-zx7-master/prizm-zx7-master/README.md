# prizm-zx7

zx7 implementation by Einar Saukas allows for low impact decompression routines with very thorough offline compression.

Include in your project by including the zx7.inl file once, and the zx7.h file anywhere else you want to use the functions described in zx7.h