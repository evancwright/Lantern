#define RASPBERRY_PI
#include "defs.h"
