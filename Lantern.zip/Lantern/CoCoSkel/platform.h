#ifndef PLATFORM_H

#define COCO
#define EXTERN 
#include "cocostructs.h"
#include <cmoc.h>

#endif

