#ifndef COCOSTRUCTS_H
#define COCOSTRUCTS_H

#include "defs.h"

typedef struct _WordEntry 
{
	BYTE id;
	char *wrd;
} WordEntry;

typedef struct _Object
{
	BYTE attrs[17];
	unsigned short flags;
} Object;

typedef struct Sentence
{
	BYTE verb;
	BYTE dobj;
	BYTE prep;
	BYTE iobj;
	void (*handler)();
} Sentence;

typedef struct _ObjectWordEntry
{
	BYTE id;
	BYTE word1;
	BYTE word2;
	BYTE word3;
} ObjectWordEntry;

typedef struct _VerbCheck
{
	BYTE verbId;
	BOOL (*check)();
} VerbCheck;


#endif
